$(document).ready(function () {
    $("header").hover(function() {
        $(this).css("text-color", "green"); 
    }, function() {
        $(this).css("text-color", "black");
});
});